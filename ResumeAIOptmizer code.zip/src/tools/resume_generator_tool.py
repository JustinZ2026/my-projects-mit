"""
简历生成和导出工具
根据用户简历和招聘要求生成优化后的简历，并导出为可下载的格式
"""
import os
import json
from typing import Optional
from datetime import datetime
from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_utils.runtime_ctx.context import new_context
from coze_coding_dev_sdk import LLMClient
from coze_coding_dev_sdk.s3 import S3SyncStorage
from langchain_core.messages import HumanMessage

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:
    Document = None


@tool
def optimize_resume(resume_text: str, job_requirements: str, runtime: ToolRuntime = None) -> str:
    """
    根据招聘要求优化简历内容
    
    Args:
        resume_text: 原始简历的文本内容
        job_requirements: 招聘要求的文本内容
    
    Returns:
        str: 优化后的简历内容
    """
    ctx = runtime.context if runtime else new_context(method="optimize_resume")
    
    try:
        client = LLMClient(ctx=ctx)
        
        prompt = f"""你是一位专业的简历优化专家。请根据提供的招聘要求，对用户的简历进行优化。

招聘要求：
{job_requirements}

原始简历：
{resume_text}

请按照以下原则进行优化：

1. **匹配度优化**：
   - 仔细分析招聘要求中的关键词和技能要求
   - 在简历中突出与招聘要求匹配的经验和技能
   - 调整工作经历和项目经验的描述，使用招聘要求中的词汇

2. **内容优化**：
   - 强化成果导向：用数据和具体成果展示能力（如"提升了20%的效率"、"管理5人团队"）
   - 使用强有力的动词开头：如"主导"、"策划"、"优化"、"推动"等
   - 量化工作成果：尽可能使用数字、百分比、时间等量化指标

3. **结构优化**：
   - 保持逻辑清晰，从重要到次要排序
   - 确保没有语法错误和错别字
   - 保持简洁明了，去除冗余信息

4. **真实性**：
   - **严禁编造**任何虚假经历或技能
   - 只能对真实经历进行更好的包装和表达
   - 如果某些要求确实不符合，诚实地保留原状

请输出优化后的完整简历内容，包含以下部分：
- 个人信息
- 求职意向
- 教育背景
- 工作经历
- 项目经验
- 专业技能
- 自我评价

注意：
- 保持格式清晰，使用Markdown格式
- 不要改变个人信息的基本事实
- 确保内容真实可信，不夸大不虚构"""

        message = HumanMessage(content=prompt)
        
        response = client.invoke(
            messages=[message],
            temperature=0.7
        )
        
        # 处理响应内容
        if isinstance(response.content, str):
            return response.content
        elif isinstance(response.content, list):
            if response.content and isinstance(response.content[0], str):
                return " ".join(response.content)
            else:
                text_parts = []
                for item in response.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                return " ".join(text_parts)
        else:
            return str(response.content)
            
    except Exception as e:
        return f"Error optimizing resume: {str(e)}"


def _parse_resume_to_dict(resume_markdown: str) -> dict:
    """
    将Markdown格式的简历解析为字典结构
    
    Args:
        resume_markdown: Markdown格式的简历内容
    
    Returns:
        dict: 解析后的简历字典
    """
    resume_data = {
        "personal_info": {},
        "job_intention": "",
        "education": [],
        "work_experience": [],
        "projects": [],
        "skills": "",
        "self_evaluation": ""
    }
    
    lines = resume_markdown.split('\n')
    current_section = None
    current_content = []
    
    for line in lines:
        line = line.strip()
        
        # 检测标题
        if line.startswith('#') or line in ['个人信息', '求职意向', '教育背景', '工作经历', '项目经验', '专业技能', '自我评价']:
            # 保存上一节内容
            if current_section:
                content = '\n'.join(current_content).strip()
                if current_section == '个人信息':
                    resume_data['personal_info'] = content
                elif current_section == '求职意向':
                    resume_data['job_intention'] = content
                elif current_section == '教育背景':
                    resume_data['education'] = [item.strip() for item in content.split('\n\n') if item.strip()]
                elif current_section == '工作经历':
                    resume_data['work_experience'] = [item.strip() for item in content.split('\n\n') if item.strip()]
                elif current_section == '项目经验':
                    resume_data['projects'] = [item.strip() for item in content.split('\n\n') if item.strip()]
                elif current_section == '专业技能':
                    resume_data['skills'] = content
                elif current_section == '自我评价':
                    resume_data['self_evaluation'] = content
            
            # 确定当前节
            if '个人' in line:
                current_section = '个人信息'
            elif '求职' in line or '意向' in line:
                current_section = '求职意向'
            elif '教育' in line:
                current_section = '教育背景'
            elif '工作' in line or '经历' in line:
                current_section = '工作经历'
            elif '项目' in line:
                current_section = '项目经验'
            elif '技能' in line:
                current_section = '专业技能'
            elif '自我' in line or '评价' in line:
                current_section = '自我评价'
            else:
                current_section = None
            
            current_content = []
        else:
            current_content.append(line)
    
    # 保存最后一节
    if current_section:
        content = '\n'.join(current_content).strip()
        if current_section == '个人信息':
            resume_data['personal_info'] = content
        elif current_section == '求职意向':
            resume_data['job_intention'] = content
        elif current_section == '教育背景':
            resume_data['education'] = [item.strip() for item in content.split('\n\n') if item.strip()]
        elif current_section == '工作经历':
            resume_data['work_experience'] = [item.strip() for item in content.split('\n\n') if item.strip()]
        elif current_section == '项目经验':
            resume_data['projects'] = [item.strip() for item in content.split('\n\n') if item.strip()]
        elif current_section == '专业技能':
            resume_data['skills'] = content
        elif current_section == '自我评价':
            resume_data['self_evaluation'] = content
    
    return resume_data


def _create_docx_resume(resume_data: dict) -> bytes:
    """
    创建DOCX格式的简历
    
    Args:
        resume_data: 简历数据字典
    
    Returns:
        bytes: DOCX文件的字节数据
    """
    if Document is None:
        raise Exception("python-docx library not installed")
    
    doc = Document()
    
    # 1. 个人信息
    p = doc.add_paragraph()
    p.add_run("个人信息").bold = True
    if resume_data.get('personal_info'):
        doc.add_paragraph(resume_data['personal_info'])
    doc.add_paragraph()  # 空行
    
    # 2. 求职意向
    if resume_data.get('job_intention'):
        p = doc.add_paragraph()
        p.add_run("求职意向").bold = True
        doc.add_paragraph(resume_data['job_intention'])
        doc.add_paragraph()
    
    # 3. 教育背景
    if resume_data.get('education'):
        p = doc.add_paragraph()
        p.add_run("教育背景").bold = True
        for edu in resume_data['education']:
            doc.add_paragraph(edu)
        doc.add_paragraph()
    
    # 4. 工作经历
    if resume_data.get('work_experience'):
        p = doc.add_paragraph()
        p.add_run("工作经历").bold = True
        for work in resume_data['work_experience']:
            doc.add_paragraph(work)
            doc.add_paragraph()  # 每段经历后空一行
    
    # 5. 项目经验
    if resume_data.get('projects'):
        p = doc.add_paragraph()
        p.add_run("项目经验").bold = True
        for proj in resume_data['projects']:
            doc.add_paragraph(proj)
            doc.add_paragraph()
    
    # 6. 专业技能
    if resume_data.get('skills'):
        p = doc.add_paragraph()
        p.add_run("专业技能").bold = True
        doc.add_paragraph(resume_data['skills'])
        doc.add_paragraph()
    
    # 7. 自我评价
    if resume_data.get('self_evaluation'):
        p = doc.add_paragraph()
        p.add_run("自我评价").bold = True
        doc.add_paragraph(resume_data['self_evaluation'])
    
    # 保存到内存
    from io import BytesIO
    output = BytesIO()
    doc.save(output)
    output.seek(0)
    
    return output.getvalue()


@tool
def export_resume_to_file(resume_content: str, file_format: str = "md", filename: Optional[str] = None, runtime: ToolRuntime = None) -> str:
    """
    将优化后的简历导出为文件并上传到对象存储，返回下载链接
    
    Args:
        resume_content: 优化后的简历内容（Markdown格式）
        file_format: 导出格式，支持：md（Markdown，推荐）、docx、txt
        filename: 自定义文件名（不含扩展名），如果不指定则默认为 "jianli"
    
    Returns:
        str: 包含文件下载URL和文件信息的JSON字符串
    """
    ctx = runtime.context if runtime else new_context(method="export_resume")
    
    try:
        # 生成文件名 - 默认使用 jianli，避免中文乱码
        if not filename:
            filename = "jianli"
        
        # 准备文件内容
        file_content = None
        content_type = None
        extension = None
        
        if file_format.lower() == 'docx':
            # 解析简历并生成DOCX
            resume_data = _parse_resume_to_dict(resume_content)
            file_content = _create_docx_resume(resume_data)
            content_type = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            extension = 'docx'
        elif file_format.lower() == 'txt':
            # 直接使用Markdown内容
            file_content = resume_content.encode('utf-8')
            content_type = 'text/plain; charset=utf-8'
            extension = 'txt'
        elif file_format.lower() in ['md', 'markdown']:
            # 直接使用Markdown内容，推荐格式
            # 使用纯UTF-8编码，不添加BOM
            file_content = resume_content.encode('utf-8')
            content_type = 'text/markdown; charset=utf-8'
            extension = 'md'
        else:
            return json.dumps({
                "success": False,
                "error": f"Unsupported file format: {file_format}. Supported formats: docx, txt, md (markdown)"
            }, ensure_ascii=False)
        
        # 上传到对象存储
        storage = S3SyncStorage(
            endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
            access_key="",
            secret_key="",
            bucket_name=os.getenv("COZE_BUCKET_NAME"),
            region="cn-beijing",
        )
        
        # 文件名固定为 jianli.md 或用户指定的格式
        file_name = f"jianli.{extension}"
        
        # 使用stream_upload_file上传
        from io import BytesIO
        file_obj = BytesIO(file_content)
        
        file_key = storage.stream_upload_file(
            fileobj=file_obj,
            file_name=file_name,
            content_type=content_type
        )
        
        # 生成签名URL（有效期1小时）
        download_url = storage.generate_presigned_url(
            key=file_key,
            expire_time=3600
        )
        
        # 返回结果
        result = {
            "success": True,
            "file_key": file_key,
            "file_name": file_name,
            "file_format": extension,
            "download_url": download_url,
            "expires_in": 3600,
            "message": f"简历已成功导出为 {extension.upper()} 格式，文件名：{file_name}，请在1小时内下载",
            "instructions": f"下载后请用文本编辑器（如记事本、VSCode、Typora）打开文件查看"
        }
        
        return json.dumps(result, ensure_ascii=False)
        
    except Exception as e:
        error_result = {
            "success": False,
            "error": str(e),
            "message": f"导出简历时出错：{str(e)}"
        }
        return json.dumps(error_result, ensure_ascii=False)


@tool
def analyze_resume_match(resume_text: str, job_requirements: str, runtime: ToolRuntime = None) -> str:
    """
    分析简历与招聘要求的匹配度
    
    Args:
        resume_text: 简历内容
        job_requirements: 招聘要求
    
    Returns:
        str: 匹配度分析报告（JSON格式）
    """
    ctx = runtime.context if runtime else new_context(method="analyze_match")
    
    try:
        client = LLMClient(ctx=ctx)
        
        prompt = f"""请分析以下简历与招聘要求的匹配度。

招聘要求：
{job_requirements}

简历内容：
{resume_text}

请从以下维度进行分析，并以JSON格式返回：

1. **整体匹配度评分**：0-100分
2. **硬技能匹配度**：列出招聘要求中的技能，并说明简历中的匹配情况
3. **工作经验匹配度**：分析工作经验年限、行业、职位是否匹配
4. **教育背景匹配度**：分析学历、专业是否匹配
5. **优势分析**：简历中符合招聘要求的亮点
6. **差距分析**：简历中缺失或不足的部分
7. **优化建议**：针对性的优化建议

请以以下JSON格式返回：
{{
    "overall_match_score": 85,
    "skill_match": {{
        "matched_skills": ["技能1", "技能2"],
        "missing_skills": ["技能3"],
        "match_rate": "70%"
    }},
    "experience_match": {{
        "is_matched": true,
        "analysis": "详细分析"
    }},
    "education_match": {{
        "is_matched": true,
        "analysis": "详细分析"
    }},
    "strengths": ["优势1", "优势2"],
    "gaps": ["差距1", "差距2"],
    "suggestions": ["建议1", "建议2"]
}}

注意：
- 保持JSON格式正确，不要包含其他说明文字
- 客观分析，不要过度夸张
- 提供建设性的优化建议"""

        message = HumanMessage(content=prompt)
        
        response = client.invoke(
            messages=[message],
            temperature=0.3
        )
        
        # 处理响应内容
        if isinstance(response.content, str):
            return response.content
        elif isinstance(response.content, list):
            if response.content and isinstance(response.content[0], str):
                return " ".join(response.content)
            else:
                text_parts = []
                for item in response.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                return " ".join(text_parts)
        else:
            return str(response.content)
            
    except Exception as e:
        return f"Error analyzing match: {str(e)}"


@tool
def generate_resume_from_requirements(job_requirements: str, runtime: ToolRuntime = None) -> str:
    """
    根据招聘要求生成简历（工作流2）
    
    Args:
        job_requirements: 招聘要求的文本内容
    
    Returns:
        str: 生成的简历内容（Markdown格式）
    """
    ctx = runtime.context if runtime else new_context(method="generate_resume")
    
    try:
        client = LLMClient(ctx=ctx)
        
        prompt = f"""你是【简历架构师】，请根据提供的招聘要求生成一份专业的简历。

招聘要求：
{job_requirements}

请按照以下步骤生成简历：

## 步骤1：需求总结
以【招聘需求分析师】身份，解析岗位需求，提取以下信息：
- 3-5个核心职责
- 4-6个关键能力
- 5-8个关键词

## 步骤2：简历生成
以【简历架构师】身份，根据招聘要点设计简历结构，填充模拟内容：

### 基本信息
- 使用占位符：姓名（如"张三"）、联系方式（如"138XXXX1234"）、邮箱（如"zhangsan@email.com"）
- 包含必要信息：姓名、联系方式、邮箱、GitHub（可选）

### 职业目标
- 2-3句话，明确求职意向
- 结合岗位要求和常见经验年限（如3-5年）
- 突出核心优势

### 核心能力
- 列出与岗位关键能力匹配的技能
- 分为技术能力、业务能力、软技能

### 工作经历
- 模拟2-3段与岗位相关的工作经历
- 按时间倒序排列
- 每段经历包含：公司名称、职位、时间、主要职责和量化成果
- 使用主动动词（主导、设计、优化、开发等）
- 量化成果（提升XX%、支撑XX万+用户、响应时间XXms等）

### 项目经验
- 模拟1-2个与岗位相关的项目
- 使用STAR法则（情境-任务-行动-结果）
- 突出技术栈和业务价值

### 教育背景
- 模拟本科/硕士学历
- 包含：学校名称、专业、学历、时间
- 可添加主修课程和获奖情况

### 技能
- 分为硬技能和软技能
- 硬技能：编程语言、框架、工具等
- 软技能：团队协作、沟通能力、问题解决等

## 约束条件
1. 模拟内容需符合职场逻辑，避免虚构不存在的经历
2. 使用占位符（如"张三"、"138XXXX1234"），避免使用真实个人信息
3. 量化成果要合理（如\"支撑10万+用户\"可以，\"支撑1亿+用户\"对初级岗位不合适）
4. 使用岗位需求中的关键词
5. 格式清晰，使用Markdown格式
6. 避免使用表格、图片等复杂格式

请以以下Markdown格式输出简历：

## 招聘要点总结
### 核心职责
（列出3-5个核心职责）

### 关键能力
（列出4-6个关键能力）

### 关键词
（列出5-8个关键词）

## 基本信息
（基本信息内容）

## 职业目标
（职业目标内容）

## 工作经历
（工作经历内容）

## 项目经验
（项目经验内容）

## 技能
（技能内容）

注意：
- 仅输出简历内容，不要包含其他说明文字
- 保持Markdown格式正确
- 确保内容真实可信，符合职场逻辑"""

        message = HumanMessage(content=prompt)
        
        response = client.invoke(
            messages=[message],
            temperature=0.7
        )
        
        # 处理响应内容
        if isinstance(response.content, str):
            return response.content
        elif isinstance(response.content, list):
            if response.content and isinstance(response.content[0], str):
                return " ".join(response.content)
            else:
                text_parts = []
                for item in response.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                return " ".join(text_parts)
        else:
            return str(response.content)
            
    except Exception as e:
        return f"Error generating resume: {str(e)}"


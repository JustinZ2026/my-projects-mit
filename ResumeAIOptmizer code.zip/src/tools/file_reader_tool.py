"""
文件读取工具
支持读取多种格式的文件：PDF、DOCX、TXT、PNG、JPG
"""
import os
from typing import Optional
from langchain.tools import tool
from langchain.tools import ToolRuntime
from coze_coding_utils.runtime_ctx.context import new_context
from coze_coding_dev_sdk import LLMClient
from langchain_core.messages import HumanMessage

# 尝试导入文件处理库
try:
    import docx
    from docx import Document
except ImportError:
    Document = None

try:
    import PyPDF2
    from PyPDF2 import PdfReader
except ImportError:
    PdfReader = None

try:
    import pdfplumber
except ImportError:
    pdfplumber = None


def _read_docx(file_path: str) -> str:
    """读取DOCX文件内容"""
    if Document is None:
        return "Error: python-docx library not installed"
    
    try:
        doc = Document(file_path)
        text_content = []
        for para in doc.paragraphs:
            text_content.append(para.text)
        
        # 读取表格
        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text for cell in row.cells]
                text_content.append(" | ".join(row_text))
        
        return "\n".join(text_content)
    except Exception as e:
        return f"Error reading DOCX file: {str(e)}"


def _read_pdf(file_path: str) -> str:
    """读取PDF文件内容"""
    # 优先使用 pdfplumber（更准确）
    if pdfplumber is not None:
        try:
            text_content = []
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    text = page.extract_text()
                    if text:
                        text_content.append(text)
            return "\n\n".join(text_content)
        except Exception as e:
            # 如果 pdfplumber 失败，尝试使用 PyPDF2
            pass
    
    # 使用 PyPDF2 作为备选
    if PdfReader is not None:
        try:
            text_content = []
            with open(file_path, 'rb') as file:
                reader = PdfReader(file)
                for page in reader.pages:
                    text = page.extract_text()
                    if text:
                        text_content.append(text)
            return "\n\n".join(text_content)
        except Exception as e:
            return f"Error reading PDF file: {str(e)}"
    
    return "Error: Neither pdfplumber nor PyPDF2 library installed"


def _read_txt(file_path: str) -> str:
    """读取TXT文件内容"""
    try:
        # 尝试多种编码
        encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1']
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as file:
                    return file.read()
            except UnicodeDecodeError:
                continue
        return "Error: Unable to decode file with any supported encoding"
    except Exception as e:
        return f"Error reading TXT file: {str(e)}"


def _read_image_with_vision(image_path: str) -> str:
    """使用视觉模型读取图片内容"""
    try:
        ctx = new_context(method="read_image")
        client = LLMClient(ctx=ctx)
        
        # 构建多模态消息
        # 注意：image_path 需要是文件URL，如果是本地路径需要先上传到对象存储
        # 这里假设用户会提供URL或者文件已经在对象存储中
        message = HumanMessage(content=[
            {
                "type": "text",
                "text": "请仔细提取这张图片中的所有文字内容，包括标题、正文、表格等。保持原有的格式和结构。如果这是一份简历，请特别注意提取个人信息、工作经历、教育背景、技能等所有关键信息。"
            },
            {
                "type": "image_url",
                "image_url": {"url": image_path}
            }
        ])
        
        response = client.invoke(
            messages=[message],
            model="doubao-seed-1-6-vision-250815",
            temperature=0.1
        )
        
        # 处理响应内容
        if isinstance(response.content, str):
            return response.content
        elif isinstance(response.content, list):
            if response.content and isinstance(response.content[0], str):
                return " ".join(response.content)
            else:
                text_parts = []
                for item in response.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                return " ".join(text_parts)
        else:
            return str(response.content)
            
    except Exception as e:
        return f"Error reading image with vision model: {str(e)}"


@tool
def read_file(file_path: str, file_type: str, runtime: ToolRuntime = None) -> str:
    """
    读取多种格式文件的内容
    
    Args:
        file_path: 文件路径或URL
        file_type: 文件类型，支持：pdf, docx, txt, png, jpg, jpeg
    
    Returns:
        str: 文件的文本内容
    """
    ctx = runtime.context if runtime else new_context(method="read_file")
    
    file_type = file_type.lower().strip()
    
    # 检查文件是否存在（如果是本地路径）
    if not file_path.startswith(('http://', 'https://')):
        if not os.path.exists(file_path):
            return f"Error: File not found at {file_path}"
    
    try:
        if file_type == 'docx':
            return _read_docx(file_path)
        elif file_type == 'pdf':
            return _read_pdf(file_path)
        elif file_type == 'txt':
            return _read_txt(file_path)
        elif file_type in ['png', 'jpg', 'jpeg']:
            # 图片文件使用视觉模型
            return _read_image_with_vision(file_path)
        else:
            return f"Error: Unsupported file type '{file_type}'. Supported types: pdf, docx, txt, png, jpg, jpeg"
    except Exception as e:
        return f"Error processing file: {str(e)}"


@tool
def analyze_resume_content(resume_text: str, runtime: ToolRuntime = None) -> str:
    """
    分析简历内容，提取关键信息
    
    Args:
        resume_text: 简历的文本内容
    
    Returns:
        str: 包含简历分析结果的JSON格式字符串
    """
    ctx = runtime.context if runtime else new_context(method="analyze_resume")
    
    try:
        client = LLMClient(ctx=ctx)
        
        prompt = f"""请分析以下简历内容，提取关键信息并以JSON格式返回。请确保提取以下信息：

1. 个人信息：姓名、联系方式、邮箱等
2. 求职意向：目标职位、期望薪资、工作地点等
3. 教育背景：学校、专业、学历、毕业时间等
4. 工作经历：公司名称、职位、工作时间、主要职责和成就
5. 技能：专业技能、语言能力、证书等
6. 项目经验：项目名称、时间、职责、成果
7. 自我评价：个人优势和特点

简历内容：
{resume_text}

请以以下JSON格式返回：
{{
    "personal_info": {{
        "name": "",
        "contact": "",
        "email": ""
    }},
    "job_intention": {{
        "target_position": "",
        "expected_salary": "",
        "location": ""
    }},
    "education": [],
    "work_experience": [],
    "skills": [],
    "projects": [],
    "self_evaluation": ""
}}

注意：
- 如果某些信息不存在，请使用空字符串或空数组
- 保持JSON格式正确，不要包含其他说明文字
- 工作经历和教育背景应该是数组，每个元素包含详细信息"""

        message = HumanMessage(content=prompt)
        
        response = client.invoke(
            messages=[message],
            temperature=0.1
        )
        
        # 处理响应内容
        if isinstance(response.content, str):
            return response.content
        elif isinstance(response.content, list):
            if response.content and isinstance(response.content[0], str):
                return " ".join(response.content)
            else:
                text_parts = []
                for item in response.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                return " ".join(text_parts)
        else:
            return str(response.content)
            
    except Exception as e:
        return f"Error analyzing resume: {str(e)}"


@tool
def summarize_job_requirements(requirements_text: str, runtime: ToolRuntime = None) -> str:
    """
    总结招聘要求内容
    
    Args:
        requirements_text: 招聘要求的文本内容
    
    Returns:
        str: 招聘要求总结的JSON格式字符串
    """
    ctx = runtime.context if runtime else new_context(method="summarize_requirements")
    
    try:
        client = LLMClient(ctx=ctx)
        
        prompt = f"""请分析以下招聘要求内容，总结关键信息并以JSON格式返回。请提取以下信息：

1. 职位基本信息：职位名称、公司名称、工作地点、薪资范围等
2. 岗位职责：主要工作内容和职责
3. 任职要求：
   - 学历要求
   - 专业要求
   - 工作经验要求
   - 技能要求（硬技能和软技能）
   - 语言要求
   - 其他要求（如证书、年龄等）
4. 加分项：额外的优势条件

招聘要求内容：
{requirements_text}

请以以下JSON格式返回：
{{
    "position_info": {{
        "position_name": "",
        "company_name": "",
        "location": "",
        "salary_range": ""
    }},
    "responsibilities": [],
    "requirements": {{
        "education": "",
        "major": "",
        "experience": "",
        "skills": [],
        "languages": [],
        "others": ""
    }},
    "bonus_points": []
}}

注意：
- 如果某些信息不存在，请使用空字符串或空数组
- 保持JSON格式正确，不要包含其他说明文字"""

        message = HumanMessage(content=prompt)
        
        response = client.invoke(
            messages=[message],
            temperature=0.1
        )
        
        # 处理响应内容
        if isinstance(response.content, str):
            return response.content
        elif isinstance(response.content, list):
            if response.content and isinstance(response.content[0], str):
                return " ".join(response.content)
            else:
                text_parts = []
                for item in response.content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                return " ".join(text_parts)
        else:
            return str(response.content)
            
    except Exception as e:
        return f"Error summarizing job requirements: {str(e)}"
